create definer = admin1@`%` view myview01 as
select `test`.`s`.`id`   AS `id`,
       `test`.`s`.`name` AS `name`,
       `test`.`s`.`sex`  AS `sex`,
       `test`.`s`.`age`  AS `age`,
       `test`.`s`.`sal`  AS `sal`,
       `test`.`s`.`c_id` AS `c_id`
from `test`.`s`;

