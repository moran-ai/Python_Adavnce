create definer = admin1@`%` view view1 as
select `test`.`s`.`c_id` AS `c_id`, `test`.`s`.`name` AS `name`, `test`.`s`.`sex` AS `sex`
from `test`.`s`
where (`test`.`s`.`c_id` = 1);

