create
    definer = admin1@`%` procedure pro1(IN n varchar(32), OUT num int)
begin
    if n is null or n = '' then
        select * from s;
    else
        select * from s where name like  concat('%', n, '%');
    end if;
    select found_rows() into num; -- 返回值
end;

