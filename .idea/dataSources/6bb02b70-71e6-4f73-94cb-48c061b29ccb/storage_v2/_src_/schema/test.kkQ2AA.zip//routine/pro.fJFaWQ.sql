create
    definer = admin1@`%` procedure pro(IN name varchar(20))
begin
    if name is null or name = '' then
        select * from s;
    else
        select * from s where name like concat('%', name, '%');
#         select @@transaction_isolation;
    end if;
end;

