create
    definer = admin1@`%` procedure pro(IN n varchar(32))
begin
    if n is null or n = '' then
        select * from s;
    else
        select * from s where name like concat('%', n, '%');
    end if;
end;

